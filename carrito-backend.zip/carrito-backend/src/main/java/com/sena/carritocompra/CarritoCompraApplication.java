package com.sena.carritocompra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarritoCompraApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarritoCompraApplication.class, args);
	}

}
