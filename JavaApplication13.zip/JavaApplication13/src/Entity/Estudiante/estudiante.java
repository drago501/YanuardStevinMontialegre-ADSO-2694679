package Entity.Estudiante;
import Utils.FunctionNumeric;
import Utils.FunctionString;





public class estudiante {
    
    
    String nivel;
    double promedio;
    int materiasReprobadas;

    public estudiante(String nivel, double promedio, int materiasReprobadas) {
        this.nivel = nivel;
        this.promedio = promedio;
        this.materiasReprobadas = materiasReprobadas;
    }

    public String getNivel() {
        return nivel;
    }

    public double getPromedio() {
        return promedio;
    }

    public int getMateriasReprobadas() {
        return materiasReprobadas;
    }

    public  static double calcularColegiatura(estudiante es) {
         double costoPorUnidad;
         
         
         

        if (es.getNivel()=="preparatoria") {
            costoPorUnidad = 180;
        } else if (es.getNivel()=="profesional") {
            costoPorUnidad = 300;
        } else {
            System.out.println("Nivel de estudiante no válido.");
            return 0;
        }

        double unidadesACursar;
        if (es.getPromedio() >= 9.5) {
            unidadesACursar = 55;
            if (es.getNivel().equalsIgnoreCase("preparatoria")) {
                return unidadesACursar * costoPorUnidad * 0.75; 
            } else if (es.getNivel().equalsIgnoreCase("profesional")) {
                return unidadesACursar * costoPorUnidad * 0.8; 
            }
        } else if (es.getPromedio() >= 9 && es.getPromedio() < 9.5) {
            unidadesACursar = 50;
            return (unidadesACursar * costoPorUnidad) - (unidadesACursar * costoPorUnidad * 0.1); 
        } else if (es.getPromedio() > 7 && es.getPromedio() < 9) {
            unidadesACursar = 50;
        } else if (es.getPromedio() <= 7 && es.getMateriasReprobadas() >= 0 && es.getMateriasReprobadas() <= 3) {
            unidadesACursar = 45;
        } else if (es.getPromedio() <= 7 && es.getMateriasReprobadas() >= 4) {
            unidadesACursar = 40;
        } else {
            System.out.println("Promedio o num de materias reprobadas no valido.");
            return 0;
        }

        return unidadesACursar * costoPorUnidad;
    }

    public static void mostrarStudentInfo(estudiante es, double colegiatura) {
         System.out.println("\nColegiatura para el estudiante:");
        System.out.println("Nivel: " + es.getNivel());
        System.out.println("Promedio: " + es.getPromedio());
        System.out.println("Materias reprobadas: " + es.getMateriasReprobadas());
        System.out.println("Colegiatura: $" + colegiatura);
    }

    public double calcularColegiatura() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    

  
}
