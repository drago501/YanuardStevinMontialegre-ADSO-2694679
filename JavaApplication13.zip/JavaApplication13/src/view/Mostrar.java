package View;

import Entity.Estudiante.estudiante;
import Utils.FunctionString;
import Utils.FunctionNumeric;

public class Mostrar {
    public static void main(String[] args) {
        FunctionNumeric fn = new FunctionNumeric();
        FunctionString fs = new FunctionString();

        String nivel = fs.InputScanner("Ingrese el nivel del estudiante =preparatoria o profesional): ");
        double promedio = fn.InputDoubleNumericPositiveScanner("Ingrese el promedio del estudiante: ");
        int materiasReprobadas = fn.InputIntegerNumericScanner("Ingrese el número de materias reprobadas: ");

        estudiante es = new estudiante(nivel, promedio, materiasReprobadas);

        
        double colegiatura = estudiante.calcularColegiatura(es);


       
        estudiante.mostrarStudentInfo(es, colegiatura);
    }
    
    
}
