/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Primero;
import java.util.Scanner;
/**
 *
 * @author bonil
 */
public interface NewInterface {
    
    double leerNumero();
    boolean esMayorQueCinco(double numero);
    //-------------------------------------------
    boolean esMayora5000(double numero2);   
    double  leer_Numero();
    //-------------------------------------------
    double  leer_Numero1();
    double balorAdsoluto(double numero3);  
    //-------------------------------------------
    double  leer_Numero2();
    boolean positivoNegativo(double numero3); 
    //-------------------------------------------
    boolean esMayorA200(double numero2);   
    double  leer_Numero3();
    //--------------------------------------------
    boolean rango(double numero2, int menor,int mayor);   
    double  leer_Numero4();
    //--------------------------------------------
    double  leer_Numero5();
    boolean paraImpar(double numero3); 
    //--------------------------------------------
    double  leer_Numero6();
    //--------------------------------------------
    double leer_Numero7();
    //---------------------------------------------
    double leer_Numero8();
     boolean menorAmayor(double numero9,double numero10);  
    //--------------------------------------------
}
