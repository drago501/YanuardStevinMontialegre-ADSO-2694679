/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Primero;

import Primero.NewInterface;

/**
 *
 * @author bonil
 */
public abstract class Abstract implements NewInterface {

    @Override
    public abstract double leer_Numero();

    @Override
    public abstract boolean esMayora5000(double numero);
//------------------------------------------------------------------------------

    @Override
    public abstract boolean esMayorQueCinco(double numero);

    @Override
    public abstract double leerNumero();
//------------------------------------------------------------------------------

    @Override
    public abstract double leer_Numero1();

    @Override
    public abstract double balorAdsoluto(double numero3);

//------------------------------------------------------------------------------    
    @Override
    public abstract double leer_Numero2();

    @Override
    public abstract boolean positivoNegativo(double numero3);
//------------------------------------------------------------------------------    

    @Override
    public abstract double leer_Numero3();

    @Override
    public abstract boolean esMayorA200(double numero3);
//------------------------------------------------------------------------------
       @Override
    public abstract double leer_Numero4();

    @Override
    public abstract boolean rango (double numero2, int menor,int mayor); 
    
//------------------------------------------------------------------------------    

    @Override
    public abstract double leer_Numero5();

    @Override
    public abstract boolean paraImpar(double numero3);
//------------------------------------------------------------------------------   

    
       @Override
    public abstract double leer_Numero6();

//------------------------------------------------------------------------------
        @Override
    public abstract double leer_Numero7();

//------------------------------------------------------------------------------

   @Override
    public abstract double leer_Numero8();  
     @Override
    public abstract boolean menorAmayor(double numero9,double numero10);
    
}
