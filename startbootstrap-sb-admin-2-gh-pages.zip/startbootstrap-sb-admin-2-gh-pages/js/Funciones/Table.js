$(document).ready(function () {
    $('#tablaProductoss ').DataTable({
      "scrollX": true,
      "scrollY": 200,
    });
    $('.dataTables_length').addClass('bs-select');
  });

  